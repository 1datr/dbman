<?php 
// Расширение dbman
class DBMExtDictionary extends DBMExtention{
	
}
?>