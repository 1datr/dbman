<?php 
// Расширение dbman
class DBMExtMultilang extends DBMExtention{
	
}
?>