<?php 
// Расширение dbman
class DBMExtention{
	
}
?>